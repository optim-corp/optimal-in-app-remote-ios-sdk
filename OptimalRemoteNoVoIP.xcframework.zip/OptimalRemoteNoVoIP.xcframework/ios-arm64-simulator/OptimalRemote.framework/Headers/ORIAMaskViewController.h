//
// Copyright (c) 2025 OPTiM CORPORATION. (http://www.optim.co.jp/)
// Permission to use, copy, modify and redistribute are strongly controlled
// under the rights of OPTiM CORPORATION.
//

#ifndef ORIAMaskViewController_h
#define ORIAMaskViewController_h

#import <UIKit/UIKit.h>

@interface ORIAMaskViewController : UIViewController <UIScrollViewDelegate>

@end

#endif /* ORIAMaskViewController_h */
